#!/bin/bash

echo -e "Build dulu"

cd build

# CMake
cmake .. -G "MinGW Makefiles"
cmake --build .

cd ..

echo -e "Jalanin Dulu aja"
./build/GhiyatInventory.exe